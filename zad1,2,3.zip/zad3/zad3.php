<?php
$x = 3;  

$y = 4; 

$z; 

$z = $x + $y; 

echo($x == $y); 

echo(" "); 

echo($z != ($x + $y)); 

echo("<br>"); 

echo($x < $y); 

echo(" "); 

echo($x++ == $y); 

echo("<br>"); 

echo($x == $y--); 

echo(" "); 

echo($z / 2); 

echo("<br>"); 

echo("auto" != "moto"); 

echo(" "); 

echo(($x != $y) || ($z < $x))
?>